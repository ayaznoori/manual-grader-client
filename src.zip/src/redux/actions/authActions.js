import axios from "axios";
import Cookies from "js-cookie";

export const loginUser = (credentials) => async (dispatch) => {
    try {
        const res = await axios.post("http://localhost:5000/api/auth/login", credentials, { withCredentials: true });
        dispatch({ type: "LOGIN_SUCCESS", payload: res.data });
        Cookies.set("token", res.data.token);
    } catch (error) {
        console.error("Login Error:", error);
    }
};

export const logoutUser = () => (dispatch) => {
    Cookies.remove("token");
    dispatch({ type: "LOGOUT" });
};
